package com.camunda.transaction_rollback;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "transaction_rollback"; // BPMN Process ID

}
