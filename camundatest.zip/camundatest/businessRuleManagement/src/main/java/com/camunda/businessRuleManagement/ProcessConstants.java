package com.camunda.businessRuleManagement;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "businessRuleManagement"; // BPMN Process ID

}
