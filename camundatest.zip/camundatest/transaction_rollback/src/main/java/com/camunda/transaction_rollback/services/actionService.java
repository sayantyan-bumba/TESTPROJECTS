package com.camunda.transaction_rollback.services;

import com.camunda.transaction_rollback.model.Address;
import com.camunda.transaction_rollback.model.Customer;

public interface actionService {
   
	
	void saveCustomer(Customer customerOb)throws Exception;

	void saveAddress(Address addressOb, boolean isDBAvailable)throws Exception;
  
}
