package com.camunda.transaction_rollback.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.camunda.transaction_rollback.model.Customer;
@Repository
public interface customerRepository extends CrudRepository<Customer, Long> {

}
