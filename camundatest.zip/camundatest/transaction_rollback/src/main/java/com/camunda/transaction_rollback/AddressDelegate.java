package com.camunda.transaction_rollback;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.camunda.transaction_rollback.model.Address;
import com.camunda.transaction_rollback.services.actionService;

@Component("addressDelegate")
public class AddressDelegate implements JavaDelegate{
	private final Logger LOGGER = Logger.getLogger(AddressDelegate.class.getName());
	@Autowired
	public actionService actionServiceob;
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
			LOGGER.info("address delegate");
			boolean isDBAvailable = (boolean) execution.getVariable("isDBAvailable");
			
			Address addressOb = new Address("Andharmanik","Baduria","743401");
			try{
			actionServiceob.saveAddress(addressOb,isDBAvailable);
			}catch (Exception e) {
		        // take action		
				execution.setVariable("errorCodeNumber", "400");
				//throw new BpmnError("bpmn_error","Db is down");
				throw new RuntimeException("DB is Down so not work");
				}
			
		

	}

	

}
