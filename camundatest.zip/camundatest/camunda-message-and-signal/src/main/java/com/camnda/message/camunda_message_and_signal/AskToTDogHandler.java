package com.camnda.message.camunda_message_and_signal;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class AskToTDogHandler implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
        String question = (String)execution.getVariable("question");
        execution.getProcessEngineServices().getRuntimeService()
        		  .createMessageCorrelation("askTDogMsg")
        		  .setVariable("question", question)
        		  .correlate();
	}

}
