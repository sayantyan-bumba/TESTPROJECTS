package com.ericsson.camundasubprocess;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "camunda-subprocess"; // BPMN Process ID

}
