package com.camunda.transaction_rollback.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.camunda.transaction_rollback.model.Address;
@Repository
public interface addressRepository extends CrudRepository<Address, Long> {

}
