package com.camnda.message.camunda_message_and_signal;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "camunda-message-and-signal"; // BPMN Process ID

}
