package com.camunda.transaction_rollback.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.camunda.transaction_rollback.model.Address;
import com.camunda.transaction_rollback.model.Customer;
import com.camunda.transaction_rollback.repository.addressRepository;
import com.camunda.transaction_rollback.repository.customerRepository;
import com.camunda.transaction_rollback.services.actionService;
@Service
public class actionServiceImpl implements actionService {
    
	@Autowired
	public customerRepository customerRepositoryob;
	@Autowired
	public addressRepository addressRepositoryOb;
	
	
	
	
	@Override
	//@Transactional(rollbackFor = Exception.class)
	@Transactional
	public void saveCustomer(Customer customerOb) throws Exception {
		customerRepositoryob.save(customerOb);
		
	}


	
	@Override
	@Transactional(rollbackFor = Exception.class)
	/*@Transactional*/
	public void saveAddress(Address addressOb, boolean isDBAvailable) throws Exception {
		// TODO Auto-generated method stub
		/*if(!isDBAvailable){
			throw new Exception("DB down");
		}
		addressRepositoryOb.save(addressOb);*/
		
			
		if(!isDBAvailable){
			throw new Exception("DB down");
		}
		try {
			 addressRepositoryOb.save(addressOb);			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		
	}

}
