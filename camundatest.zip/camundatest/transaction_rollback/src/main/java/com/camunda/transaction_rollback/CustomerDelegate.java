package com.camunda.transaction_rollback;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.camunda.transaction_rollback.model.Customer;
import com.camunda.transaction_rollback.services.actionService;


@Component("customerDeligate")
public class CustomerDelegate implements JavaDelegate {

	private final Logger LOGGER = Logger.getLogger(CustomerDelegate.class.getName());
    
	@Autowired
	public actionService actionServiceob;
	
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("customer delegate");

		Customer customerOb = new Customer("Sayantan","Mukhopadhyay");
		actionServiceob.saveCustomer(customerOb);
	}

}
